package de.frankp.bike;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PedalSensorTest {

	@Test
	void test() {
		PedalSensor testee = new PedalSensor();
	}

}
