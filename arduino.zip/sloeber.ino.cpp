#ifdef __IN_ECLIPSE__
//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2018-06-21 09:04:51

#include "Arduino.h"
#include <Arduino.h>
#include <HardwareSerial.h>
#include <pins_arduino.h>
#include <Print.h>

void setup() ;
void loop() ;
void isr() ;
double getDistance() ;
double getDeltaDistance() ;
double getSpeed(double hours, double kilometers) ;
double microsToHours(unsigned long microSeconds) ;
double microsToMinutes(unsigned long microSeconds) ;
double microsToSeconds(unsigned long microSeconds) ;

#include "EBikeController.ino"


#endif
